# 论文数字来源对照表（draft-v1 + **draft-v2 增补**）

> **纪律**：初稿中**每一个数字**都必须能在此表找到来源产物与其 SHA256。
> **v2 增补**：下表末段为 P5.1（B 态修订）新增的来源行；v1 原有行**原样保留**。
> **禁止**使用未入册数字。

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| 合成配置数 | 54（2 模型 × 3 噪声 × 3 档 × 3 主频） | `frozen-v2` | `1D4AF0389EDE2328015C09943536BD6B…` |
| 观测数 | 270（54 × 5 种子） | `frozen-v2` | `1D4AF0389EDE2328015C09943536BD6B…` |
| 方法数 | 5（滤波 2 / 变换阈值 1 / 分解 1 / 低秩 1） | `frozen-v2` | `1D4AF0389EDE2328015C09943536BD6B…` |
| 融合格数 | 1620（270 × 3 档 γ × 2 配对） | `fusion/metrics.csv` | `123B8E56893D1EE02094870D78BA42AE…` |
| 互补性行数 | 540（10 对 × 3 度量 × 18 分层键） | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M2 全局（选中对） | 0.500000 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M2 全局（次名） | 0.200000 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M2 零值对数 | 8/10 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| 选中对 M1（全 10 对最低） | 0.093807 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| ΔSNR 融合（主配对 γ=0.5） | 0.0588 dB | `fusion/metrics.csv` | `123B8E56893D1EE02094870D78BA42AE…` |
| ΔSNR 融合（次优 γ=0.5） | 2.5295 dB | `fusion/metrics.csv` | `123B8E56893D1EE02094870D78BA42AE…` |
| Lsig 融合（主配对 γ=0.5） | 0.020640 | `fusion/metrics.csv` | `123B8E56893D1EE02094870D78BA42AE…` |
| Lsig 融合（次优 γ=0.5） | 0.018103 | `fusion/metrics.csv` | `123B8E56893D1EE02094870D78BA42AE…` |
| ΔSNR 逐观测 oracle（上界） | 6.7033 dB | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| ΔSNR `fk_filter`（宏平均中位） | 0.9320 dB | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| Lsig `fk_filter`（宏平均中位） | 0.009706 | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| ΔSNR `fx_deconv`（宏平均中位） | 0.0000 dB | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| Lsig `fx_deconv`（宏平均中位） | 0.029151 | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| ΔSNR `wavelet_threshold`（宏平均中位） | 0.0422 dB | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| Lsig `wavelet_threshold`（宏平均中位） | 0.015129 | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| ΔSNR `ssa_decomposition`（宏平均中位） | 0.2101 dB | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| Lsig `ssa_decomposition`（宏平均中位） | 0.045928 | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| ΔSNR `svd_lowrank`（宏平均中位） | 0.9482 dB | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| Lsig `svd_lowrank`（宏平均中位） | 0.011218 | `metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| vs 最差单法 ΔSNR：中位差 / p_holm | +0.054257 / 0.134687 | `supplement_vs_worst.csv` | `FAB770718583E5A297AFB06538277FAE…` |
| vs 最差单法 Lsig：中位差 / p_holm | -0.017167 / 0.00019998 | `supplement_vs_worst.csv` | `FAB770718583E5A297AFB06538277FAE…` |
| 连续性可区分性：Q1/Q2/Q3 | +0.0503 / +0.0790 / +0.0838（阈值 0.1 / 0.05 / 0.1） | `continuity_verification.json` | `D618EDD892EBEDB28C32ABE4F519FCFB…` |
| 野外 FP1 融合 / 最佳单法（部分 U） | -2.2100 / +0.6953 | `u_scores_partial.csv` | `F2238A2AF5179B7E192FC2013BE76067…` |
| 野外 FP2 融合 / 最佳单法（部分 U） | -1.0791 / +0.6359 | `u_scores_partial.csv` | `F2238A2AF5179B7E192FC2013BE76067…` |
| 重归一化权重（振幅保持） | 0.4000 | `frozen-v2（原 30/75）` | `1D4AF0389EDE2328015C09943536BD6B…` |
| 重归一化权重（频谱残差） | 0.3333 | `frozen-v2（原 25/75）` | `1D4AF0389EDE2328015C09943536BD6B…` |
| 重归一化权重（盲评） | 0.2667 | `frozen-v2（原 20/75）` | `1D4AF0389EDE2328015C09943536BD6B…` |
| M1 全局（M2 次名对） | 0.575710 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M2 分层：M1_N1 层（主配对） | 1.0000 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M2 分层：model=M1 层 / noise=N3 层（主配对） | 0.0000 / 0.0000 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M1 内积归一化（选中对） | ≈0.906 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| M2 零膨胀：8/10 对中位为 0 | 8/10 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| 连续性 Q1/Q2/Q3 判据阈值 | 0.1 / 0.05 / 0.1 | `continuity_verification.json` | `D618EDD892EBEDB28C32ABE4F519FCFB…` |
| 权重重归一化公式 | 30/25/20 ÷ 75 | `frozen-v2 item_11` | `1D4AF0389EDE2328015C09943536BD6B…` |
| γ 档（三档） | 0.4 / 0.5 / 0.6 | `fusion-rules.yaml` | `0C4D6BA3D2CA6C01E34D78A9550C4D0B…` |

## v2 增补来源（P5.1 · B 态修订）

> 以下行覆盖 **draft-v2 新增/改写句**中所用数字；v1 原有行全部保留不动。

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| **三态判定结果** | **状态 B**（无伤害 / 未被最差单法击败 / 未超最优固定单法） | `P5.1-三态签收记录…-2026-09-29.md` | `58D627225AE10743DB173C4930720198…` |
| **判定人** | 用户（张涛） | 同上 | `58D627225AE10743DB173C4930720198…` |
| **判定时间** | 2026-09-28 12:52 | 同上 | `58D627225AE10743DB173C4930720198…` |
| **计划判定日** | 11-29（提前签收） | 同上 | `58D627225AE10743DB173C4930720198…` |
| 主频档 `f_main_hz` | 15.0 / 25.0 / 40.0 Hz | `frozen-v2.yaml` | `1D4AF0389EDE2328015C09943536BD6B…` |
| N2 视速度槽（L1/L2/L3） | 800 / 1500 / 3000 m/s | `frozen-v2.yaml` | `1D4AF0389EDE2328015C09943536BD6B…` |
| 鉴别子分权重（d / b / a） | 0.4 / 0.3 / 0.3 | `fusion-rules.yaml` | `0C4D6BA3D2CA6C01E34D78A9550C4D0B…` |
| d 子分视速度下限 `v_lo` | 100.0 m/s | `fusion-rules.yaml` | `0C4D6BA3D2CA6C01E34D78A9550C4D0B…` |
| M2 阈值倍数（Tukey IQR×1.5） | 1.5 | `complementarity/preregistration.md` | `3B552DB95499C2ABF97DD0A38A86A41E…` |
| 分层样本量 `n_obs` 范围 | 45–135 | `complementarity.csv` | `AE0FF75F58F2E88D27F1751EF554BABE…` |
| 度量值域（M1/M2/M3） | [0, 1] | `complementarity/preregistration.md` | `3B552DB95499C2ABF97DD0A38A86A41E…` |

> **说明**：判定元数据（状态 / 判定人 / 判定时间 / 计划日）来源为 P5.1 归档任务单原件，
> 路径 `docs/task-sheets/P5.1-三态签收记录与论文B态修订-2026-09-29.md`。

## v5 增补来源（P5.4 · WS2 新增表格与数值）

> 覆盖 draft-v5 相对 draft-v4 **新增的全部数值**；v4 及更早的来源行全部保留不动。

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v5 · 配置描述表（振幅比例与实测输入 SNR） | 0.30 / 0.60 / 1.00；10.46 / 4.44 / 0.00 dB；800 / 1500 / 3000 m/s | `configs/frozen-v2.yaml` + `docs/metrics-spec.md` | `FB63E2112C2984578BAB38EAA427F6D3…` |
| v5 · 参数表（登记默认值） | 800.0 / 5.0 / 80.0 / 4 / 1e-08 / db4 / 1.0 / 64 / 8 / 0.95 | `configs/methods_registry.yaml` | `5DA2959BBE4C2C7BFB7667EF3E45A4AB…` |
| v5 · 配对清单表（10 对 M1/M2 全局中位） | 0.741185 / 0.093807 / 0.575710 / 0.500000 / 0.200000 等 | `results/complementarity10/complementarity10.csv` | `507DEEBE81A36AD2EEF37EA2DBAEEED0…` |
| v5 · 配对清单表（10 对融合 ΔSNR 中位） | 4.1515 / 0.0588 / 2.5295 等 | `results/fusion10/metrics.csv` | `E8147D0D4702F063D6DE21B20DEF6149…` |
| v5 · 秩相关表（5 定义 × 4 度量） | +0.8303 / −0.3114 / +0.6727 / −0.0779 等 | `results/fusion10/stats/gain_definition_sensitivity.csv` | `812FBB051725E57D3B5807C5DF92426A…` |
| v5 · CNA 与事件级表 | 14.6916 / 2.0804 / 6.7747 / 0.1101 / 2.8370 等 | `results/metrics.csv` + `results/fusion/metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| v5 · 主配对池化阈值 | 0.0394653 | `results/complementarity10/run_manifest.json` | `080D2A2156F94B9B0C57740D05B24512…` |
| v5 · 成员补表（单法 ΔSNR/Lsig） | 0.0000 / 0.0422 / 0.029151 / 0.015129 / 0.011218 | `results/metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |

## v6 增补来源（P5.5 · 新分析）

> 覆盖 draft-v6 相对 draft-v5 新增的数值；此前来源行全部保留不动。

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v6 · 分工表（方法 × 噪声类型中位） | 0.8528 / 5.5231 / 2.4351 / 3.3458 / 0.8715；-0.1709 / -0.1028 / -0.0000 / 0.3020 / 4.4591；12.4354 / -0.0393 / 0.0422 / -0.0323 / 0.7927 | `results/metrics.csv` | `CD7499874B4A166E6B2737152D3B0C04…` |
| v6 · 消融对照表（等权 / 纯 C² / 完整） | 4.1465 / 4.1465 / 4.1515 / 0.0050 / 0.0252 等 | `results/fusion_ablation/metrics.csv` + `results/fusion10/metrics.csv` | `1BDE916F4FF0C73B6B254F683E083BBB…` |
| v6 · 种子外验证表 | 5.5231→5.5730 / 4.4591→2.0195 / 12.4354→12.1630；量级比 1.009 / 0.453 / 0.978 | `results/validation/metrics.csv` + `results/validation/validation_manifest.json` | `37B7042B296481C740621B51C6E4A5BF…` |
| v6 · 样本外验证判据与规则 | N1→fx_deconv / N2→svd_lowrank / N3→fk_filter；判据 1 组内第一、判据 2 量级≥0.5× | `results/validation/preregistration.md` | `2C593C40286A544E7F4F01A82009275B…` |
| v6 · 附录 B 各提交哈希 | afffc32 / ff60ac5 / 866989c / 37590f9 | git 历史（可 `git show <hash>` 核验） | `37590F908D25EADCD468FDD3546E9188…` |
### v6 · 野外重跑（A1）

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v6 · 野外三配对原始指标表 | -4.5336 / 0.19939 / 1.2099 / 0.6974 / +2.0835 / 0.71220 / 2.0143 / 0.2992 / -6.0569 / 0.44160 / 2.5260 / 0.2013 / -3.5899 / 0.13804 / -5.3283 / 0.13587 / -5.4667 / 0.47916 等 | `results/field2/field_pair_metrics.csv` | `E5882B408223A027E43A1FC2361DE869…` |

### v7 增补来源（P5.6 · 配置级统计与更正）

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v7 · §4.3 配置级统计（n=54） | +0.165827 / +0.046848 / +0.326409 / 0.000200 / -0.024528 / -0.032315 / -0.006982 | `results/fusion/stats/pairwise_config.csv` + `results/stats/unit_caliber_comparison.csv` | `43D8EACB6F8CD4973F9E146899C5C6E6…` |
| v7 · §4.2 分层值更正 | 0.631579（model=M2 层）；零值层 = model=M1 / noise=N3 / M1_N2 / M1_N3 | `results/complementarity10/complementarity10.csv` | `507DEEBE81A36AD2EEF37EA2DBAEEED0…` |
| v7 · §4.5 新种子复现与分位数 | 5.9840 / 6.7033；N2 分位 19.76 / 28.90（原）与 4.59 / 21.75（新） | `results/metrics.csv` + `results/validation/metrics.csv` | `37B7042B296481C740621B51C6E4A5BF…` |
| v7 · M2 第二重伪影直接检验（窗口级） | 窗数 1110；阈值 0.217503；D>0 309、D<0 801；超阈 118（同号 87） | `results/complementarity/m2_second_artifact_test.csv` | `AD5D31EF58A72A4C51AD8C2BCE3E1BE1…` |


### v8 增补来源（P5.8 · 审稿四轮整改）

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v8 · 野外综合分 γ=0.5（统一口径） | FP1 −2.2652 / FP2 −1.1089 | `results/field/u_scores_partial.csv` | `F2238A2AF5179B7E192FC2013BE76067CAB87F6B5B58E8249462F8E59B24FC27` |
| v8 · 野外三档完整范围 | FP1 −2.3201(γ=0.4) ~ −2.2100(γ=0.6)；FP2 −1.1362 ~ −1.0791 | `results/field/u_scores_partial.csv` | `F2238A2AF5179B7E192FC2013BE76067CAB87F6B5B58E8249462F8E59B24FC27` |
| v8 · 野外全貌（劣于融合者） | FP1 F-K −15.2663、F-X −12.8650；FP2 F-K −10.8560、F-X −7.5786 | `results/field/u_scores_partial.csv` | `F2238A2AF5179B7E192FC2013BE76067CAB87F6B5B58E8249462F8E59B24FC27` |
| v8 · 选法命中率与落后 oracle | 89.3% / 81.5%；平均落后 0.27 / 0.28 dB | `results/validation/replication_diagnostics.json` | `1B56E6F790BA8EDB4E0E6FF6A4B31ACEDD707EF92B560083B41AAA93398044FC` |
| v8 · N2 命中率与分位 | 87.8% → 63.3%；75 分位 19.76 → 4.59；90 分位 28.90 → 21.75 | 同上 | `1B56E6F790BA8EDB4E0E6FF6A4B31ACEDD707EF92B560083B41AAA93398044FC` |
| v8 · N2 组内种子极差中位 | 9.41 dB（原）→ 13.52 dB（新） | 同上 | `1B56E6F790BA8EDB4E0E6FF6A4B31ACEDD707EF92B560083B41AAA93398044FC` |
| v8 · 平台值与秩选择（N2 低秩） | 平台 ≈ 34.625；k = 1（原 5/5）；新种子 1.80/3.33/34.62/5.75/34.63（k=18/12/1/7/1） | `results/metrics.csv` + `results/validation/metrics.csv` | `CD7499874B4A166E6B2737152D3B0C045232911D5D388DD46262406B11443933` |
| v8 · 层内 IQR 阈值（逐噪声类型） | N1 0.2175030056 / N2 0.0850954233 / N3 0.0177711845 | `results/complementarity10_stratified/reselection.json` | `D5085A721B588D37A9E4A3DAE129BA4C12F7990A7B326A1C8398E7E0BD775686` |
| v8 · 层内重选结果 | 主配对 M2 0.500000 → 0.000000；首位 fx_deconv\|svd_lowrank = 0.111111 | 同上 | `D5085A721B588D37A9E4A3DAE129BA4C12F7990A7B326A1C8398E7E0BD775686` |
| v8 · §5.1 同号单元（18 配置口径） | 全负 7 / 全正 0 / 混合 11 | `results/complementarity/complementarity.csv` + `results/*.npy` | `AE0FF75F58F2E88D27F1751EF554BABE50783D0A7C5A1041792107A506C9B566` |
| v8 · §4.3 成员对照（配置级 γ=0.5） | vs F-X +0.1658 [0.0468,0.3264] p=0.0003；vs 小波 +0.0267 [0.0172,0.1429] p=0.0008 | `results/fusion/stats/pairwise_config.csv` | `89E5FAC8D39742BE68CA4AF7BFD1DA436B74554028B07BAF64B03EC7C01219AD` |
| v8 · 新种子逐方法中位 | fk_filter 0.9666 / svd_lowrank 0.8833 / ssa 0.1933 / wavelet 0.0416 / fx_deconv 0.0000 | `results/validation/metrics.csv` | `37B7042B296481C740621B51C6E4A5BFD0A69C3B9E9128A6B123986B95A72A51` |

> **口径说明**：「野外综合分」一行的 −2.2652 / −1.1089 为 γ=0.5（全文统一口径）；
> 既有的 −2.2100 / −1.0791 为 γ=0.6 档，仍如实保留于上表（系同一产物的另一档）。
> 该综合分的**归一化口径未见于文档记录**，其去重敏感性经四次复算**不可复现**，已在正文如实披露。


### v9 增补与更正来源（P5.10 · 审稿人四类问题整改）

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v9 **更正** · 选法逐观测命中率（分层） | N1 82.22% / 82.22%；N2 87.78% / 63.33%；N3 97.78% / 98.89%；全局 89.26% / 81.48% | `results/validation/replication_diagnostics.json` | `1B56E6F790BA8EDB4E0E6FF6A4B31ACEDD707EF92B560083B41AAA93398044FC` |
| v9 · N2 层高增益观测占比 | $\Delta$SNR>30 dB：8/90（8.9%，原种子）与 4/90（4.4%，新种子），全部落在 M1 模型 L2 档 | `results/metrics.csv` + `results/validation/metrics.csv` | `37B7042B296481C740621B51C6E4A5BFD0A69C3B9E9128A6B123986B95A72A51` |
| v9 · M1 模型 N2 层三档最大值 | L1 23.14 dB / L2 34.63 dB / L3 28.90 dB | 同上 | `37B7042B296481C740621B51C6E4A5BFD0A69C3B9E9128A6B123986B95A72A51` |

> **更正说明**：上一版表 13 中 N1（99.3%/99.3%）与 N3（100%/99.3%）两格命中率属**无证据填写**，
> 本批按上表实算值更正。N2 与全局两行原值经复算无误。
>
> **删除**：表 11（野外综合部分分）及其去重敏感性段落自 v9 起不再引用 ——
> 该分的归一化口径未见于文档记录且复算不可复现；野外结论改由四项原始指标支撑（现表 11）。


### v9 补记（P5.9 · 门与口径）

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v9 · 新增数字门核验口径 | 分层命中率容差 ±0.05 个百分点；自带反证必报 FAIL | `execution/number_gate.py` | `B0AD53FA2FB225E45526A0636D639E87EED6D68CFFB1C6257F8B302CFB4CAC30` |
| v9 · G-reader 词表 | 26 项（P5.9 扩充 10 项：须写明/不夸大/删循环论证/表述升级/排查/本批之前/自本批起/此处更正/口径更正说明/修订史） | `execution/format_compliance.py` | `02F59AD599D036E07636D1FD27205AD27BB680075243ED4B5CD039CCF4099FDB` |


### v10 增补来源（P5.10 · 叙事重构）

| 数字/量 | 值 | 来源产物 | SHA256 |
| :--- | :--- | :--- | :--- |
| v10 · 最优固定单法（**纠截图**） | **0.9482** dB（`svd_lowrank` ΔSNR 中位 = 0.9482364203177616） | `results/stats/macro_average.csv` | `1FE1950B76A5E0E403735E04E2585942E84A532EFBA168444A90A3EC6BA0CC6C` |
| v10 · 主配对 / 对照配对融合 | 0.0588 dB / 2.5295 dB | `results/fusion/metrics.csv` | `123B8E56893D1EE02094870D78BA42AEE1E580DA79CB234D00F2281FFF9426E2` |
| v10 · 消融差上限 | ≤ 0.0252 dB | `results/fusion_ablation/metrics.csv` | `1BDE916F4FF0C73B6B254F683E083BBB5BD3B679553AD71B1F4C59F94F7B4063` |
| v10 · 层内重选（反向选择陷阱） | 主配对 M2 0.500000 → 0.000000；首位 `fx_deconv\|svd_lowrank` 0.111111 | `results/complementarity10_stratified/reselection.json` | `D5085A721B588D37A9E4A3DAE129BA4C12F7990A7B326A1C8398E7E0BD775686` |

> **截图数字更正登记**：参照截图把最优固定单法写作 0.9492，与产物实测 0.9482 不符；
> 按「截图 = 框架与语气参照，不是数字来源」的规则，**全文一律采用 0.9482**。
> v10 相对 v11 的数字差集：无（既有数字全部保留）。
